create view pg_stat_xact_user_tables
            (relid, schemaname, relname, seq_scan, seq_tup_read, idx_scan, idx_tup_fetch, n_tup_ins, n_tup_upd,
             n_tup_del, n_tup_hot_upd, n_tup_newpage_upd)
as
SELECT relid,
       schemaname,
       relname,
       seq_scan,
       seq_tup_read,
       idx_scan,
       idx_tup_fetch,
       n_tup_ins,
       n_tup_upd,
       n_tup_del,
       n_tup_hot_upd,
       n_tup_newpage_upd
FROM pg_stat_xact_all_tables
WHERE (schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND schemaname !~ '^pg_toast'::text;

alter table pg_stat_xact_user_tables
    owner to akyabutik_user;

grant select on pg_stat_xact_user_tables to public;

